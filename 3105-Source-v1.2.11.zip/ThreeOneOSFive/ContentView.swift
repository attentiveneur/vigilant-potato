import SwiftUI
import UIKit
import AVFoundation
import Combine
import UniformTypeIdentifiers

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @ObservedObject private var importer = PaksImporter.shared
    @ObservedObject private var appLog = AppLog.shared

    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var showPicker = false
    @State private var showGamePakList = false
    @State private var showAdvanced = false

    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var hspeitoffEnabled = false
    @State private var hyperBalamagicaEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimChestPackageEnabled = false
    @State private var magicEnabled = false

    private let ticker = Timer.publish(every: 6, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop()
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    brandHeader
                    warningCard
                    kernelCard
                    quadGrid
                    switchRow
                    statsRow
                    hintLine
                    secondaryRow
                    advancedSection
                    logCard
                    developerCredits
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 26)
            }

            resultPopupLayer
                .zIndex(99)
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showCleaner) {
            CleanerView()
        }
        .sheet(isPresented: $showPicker) {
            PakDocumentPicker { urls in
                importer.add(urls: urls)
            }
        }
        .sheet(isPresented: $showGamePakList) {
            GamePakListSheet(importer: importer)
        }
        .sheet(item: $patchStore.passwordRequest, onDismiss: patchStore.cancelUnlock) { _ in
            PatchUnlockPrompt(store: patchStore)
        }
        .onAppear {
            syncPatchStates()
            importer.refresh()
        }
        .onReceive(ticker) { _ in
            if !importer.busy && !importer.containerFound {
                importer.refresh()
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            importer.refresh()
            guard !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "READY — SELECT A PATCH"
        }
    }

    // MARK: - 结果弹窗（自绘浮层，不走系统 alert，保证一定弹得出来）

    private var resultPopupLayer: some View {
        Group {
            if let item = importer.pendingAlert {
                ZStack {
                    Color.black.opacity(0.66)
                        .ignoresSafeArea()
                        .onTapGesture { importer.dismissAlert() }

                    VStack(alignment: .leading, spacing: 13) {
                        HStack(spacing: 10) {
                            Image(systemName: item.success
                                  ? "checkmark.circle.fill"
                                  : "exclamationmark.triangle.fill")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundStyle(item.success ? HomeTheme.accent : HomeTheme.yellow)

                            Text(item.title)
                                .font(.system(size: 17, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)

                            Spacer(minLength: 0)
                        }

                        Text(item.message)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(3)

                        Button {
                            importer.dismissAlert()
                        } label: {
                            Text("好")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .foregroundStyle(Color.black)
                                .frame(maxWidth: .infinity, minHeight: 42)
                                .background(
                                    HomeTheme.accent,
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(18)
                    .frame(maxWidth: 330)
                    .background(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .fill(Color(red: 0.05, green: 0.10, blue: 0.08))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .stroke(HomeTheme.accent.opacity(0.55), lineWidth: 1.2)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 24, y: 10)
                    .padding(.horizontal, 30)
                }
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            }
        }
        .animation(.easeOut(duration: 0.18), value: importer.pendingAlert?.id)
    }

    // MARK: - 顶部

    private var brandHeader: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("浪神文件管理器")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("PAK 一键导入 / 一键移出")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(0.6)
                    .foregroundStyle(HomeTheme.accent.opacity(0.92))
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(HomeTheme.accent)
                    .frame(width: 44, height: 44)
                    .background(Color.black.opacity(0.34), in: Circle())
                    .overlay(Circle().stroke(HomeTheme.accent.opacity(0.45), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("设置")
        }
    }

    private var warningCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Text(importer.containerFound ? "✅" : "⚠️")
                    .font(.system(size: 14, weight: .bold))
                Text(warningHeadline)
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(HomeTheme.warnText)
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
                Spacer(minLength: 0)
            }

            Text("游戏内 pak/sig \(importer.paksCount) 个 · 待导入 \(importer.inboxFiles.count) 个 · 已导入 \(importer.importedFiles.count) 个")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.86))
                .lineLimit(2)
                .minimumScaleFactor(0.8)

            Text(appState.exploitStatus.isSuccess ? "已拿到全盘读写 → 可以直接写进游戏目录" : "这台设备没给全盘权限 → 用「改本机的包」模式")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.72))
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 11)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(HomeTheme.warnBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.warnBorder, lineWidth: 1)
        )
    }

    private var warningHeadline: String {
        if importer.containerFound {
            let who = importer.matchedBundleID.isEmpty ? "" : "（\(importer.matchedBundleID)）"
            return "已拿到游戏目录\(who) —— 可以直接导入"
        }
        return "还没拿到游戏目录 —— 先点下面「一键激活内核」"
    }

    // MARK: - 内核引擎

    private var kernelCard: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 8) {
                Label("内核引擎", systemImage: "bolt.fill")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(1.0)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Text(kernelStatusText)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(kernelStatusColor)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(kernelStatusColor.opacity(0.14), in: Capsule())
            }

            Text(kernelSubtitle)
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                appState.runKernelExploitIfNeeded()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                    Text(appState.kernelExploitRunning ? "正在激活…（10~30 秒）" : "⚡ 一键激活内核 · 全盘读写")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 14)
                .frame(maxWidth: .infinity)
                .background(HomeTheme.purple, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.white.opacity(0.18), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .disabled(appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported)
            .opacity((appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported) ? 0.55 : 1)
        }
        .padding(15)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.30), lineWidth: 1)
        )
    }

    private var kernelStatusText: String {
        if appState.kernelExploitRunning { return "激活中…" }
        if case .success = appState.exploitStatus { return "已激活" }
        if case .failed = appState.exploitStatus { return "失败" }
        if case .unsupported = appState.exploitStatus { return "不支持本系统" }
        return "未激活"
    }

    private var kernelStatusColor: Color {
        if appState.kernelExploitRunning { return HomeTheme.yellow }
        if case .success = appState.exploitStatus { return HomeTheme.accent }
        if case .failed = appState.exploitStatus { return HomeTheme.red }
        if case .unsupported = appState.exploitStatus { return HomeTheme.red }
        return HomeTheme.yellow
    }

    private var kernelSubtitle: String {
        if appState.kernelExploitRunning {
            return "正在提权，屏幕可能会卡一下，别退出、别切后台。"
        }
        if case .success = appState.exploitStatus {
            return "内核读写和沙盒逃逸都在了，可以直接把 pak 写进游戏 Paks。"
        }
        if case .failed = appState.exploitStatus {
            if isExperimentalSystem {
                return "这台是 iOS \(AppInfo.osVersion)：内核扫描这条通道只做到 26.0.x，在这台上用不了，这个红字不用管。① 导入、② 修复、读写游戏 Paks 走的是另一条通道，照常能用。"
            }
            return "这次没成功（漏洞有概率失败）。把 App 划掉重开，再点一次。"
        }
        if case .unsupported(let version) = appState.exploitStatus {
            return "iOS \(version) 的内核扫描没验证过（验证到 17.0–17.7 / 18.0–18.7.1 / 26.0.x）。这个红字不影响 ① 导入、② 修复和读写游戏 Paks，那条通道不经过内核。"
        }
        if isExperimentalSystem {
            return "iOS \(AppInfo.osVersion)：内核扫描这条通道只做到 26.0.x，点了会失败，不用点。① 导入、② 修复、读写游戏 Paks 走另一条通道，现在就能用。"
        }
        return "点一下，自动完成内核读写和沙盒逃逸，之后才能写进游戏目录。"
    }

    private var isExperimentalSystem: Bool {
        let v = AppInfo.versionTuple
        return ExploitSupportPolicy.isExperimental(major: v.major, minor: v.minor)
    }

    // MARK: - 四宫格

    private var quadGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            quadCard(title: "① 导入文件",
                     subtitle: "待导入 \(importer.inboxFiles.count) 个",
                     systemImage: "doc.fill",
                     tint: HomeTheme.green) {
                importer.importAll()
            }

            quadCard(title: "② 修复",
                     subtitle: importer.importedFiles.isEmpty ? "还没导入过" : "已导入 \(importer.importedFiles.count) 个",
                     systemImage: "wrench.fill",
                     tint: HomeTheme.red) {
                importer.deleteImported()
            }

            quadCard(title: "③ 从手机里选文件",
                     subtitle: "选完自动进「待导入」",
                     systemImage: "iphone",
                     tint: HomeTheme.blue) {
                showPicker = true
            }

            quadCard(title: "④ 全盘找 pak",
                     subtitle: "看看游戏里都有啥",
                     systemImage: "magnifyingglass",
                     tint: HomeTheme.purple) {
                importer.refreshGamePaks()
                showGamePakList = true
            }
        }
    }

    private func quadCard(title: String, subtitle: String, systemImage: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: systemImage)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 34, height: 34)
                    .background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)

                Text(subtitle)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .padding(13)
            .background(tint.opacity(0.62), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.16), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(importer.busy)
        .opacity(importer.busy ? 0.55 : 1)
    }

    // MARK: - 开关行

    private var switchRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.setBackup(!importer.backupEnabled)
            } label: {
                chip(title: "💾 备份：\(importer.backupEnabled ? "开" : "关")",
                     tint: importer.backupEnabled ? HomeTheme.green : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.setWipeBackup(!importer.wipeBackupEnabled)
            } label: {
                chip(title: "🧹 连备份删：\(importer.wipeBackupEnabled ? "开" : "关")",
                     tint: importer.wipeBackupEnabled ? HomeTheme.green.opacity(0.82) : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.refresh()
            } label: {
                chip(title: "🔄 刷新", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    private func chip(title: String, tint: Color) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .frame(maxWidth: .infinity, minHeight: 40)
            .padding(.horizontal, 6)
            .background(tint, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
    }

    // MARK: - 数字框

    private var statsRow: some View {
        HStack(spacing: 10) {
            statBox(value: importer.inboxFiles.count, title: "待导入")
            statBox(value: importer.importedFiles.count, title: "已导入")
            statBox(value: importer.paksCount, title: "游戏里的包")
        }
    }

    private func statBox(value: Int, title: String) -> some View {
        VStack(spacing: 3) {
            Text("\(value)")
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(HomeTheme.accent)
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.60))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, minHeight: 62)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.18), lineWidth: 1)
        )
    }

    private var hintLine: some View {
        Text(importerHint)
            .font(.system(size: 10, weight: .medium, design: .rounded))
            .foregroundStyle(.white.opacity(0.52))
            .multilineTextAlignment(.leading)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var importerHint: String {
        if importer.busy { return "正在处理，别退出 App，也别切后台。" }
        if !importer.lastResult.isEmpty { return importer.lastResult }
        if importer.inboxFiles.isEmpty {
            return "待导入是空的：点「③ 从手机里选文件」，或者在文件 App 里长按 pak → 共享 → 浪神文件管理器，也会自动进来。"
        }
        return "点「① 导入文件」直接覆盖游戏里的同名原件（备份开着就先存一份），点「② 修复」把导进去的那几个从游戏里直接删掉，不还原原件。"
    }

    private var secondaryRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.claimImported()
            } label: {
                chip(title: "📥 认领已导入的", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.clearStaleRecords()
            } label: {
                chip(title: "🧹 清掉失效记录", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 进阶（原功能全在这里）

    private var advancedSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showAdvanced.toggle()
                }
            } label: {
                HStack(spacing: 8) {
                    Text("Aa 改字（进阶 · 跟导入无关）")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.86))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .black))
                        .foregroundStyle(HomeTheme.accent)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            if showAdvanced {
                patchOptions
                gameLaunchPanel
                Button {
                    showCleaner = true
                } label: {
                    Label("清理缓存与临时文件", systemImage: "trash.slash.fill")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(HomeTheme.accent.opacity(0.34), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: - 运行记录

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                Label("运行记录", systemImage: "list.bullet.rectangle")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Button {
                    appLog.entries.removeAll()
                } label: {
                    Text("清空")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(Color.white.opacity(0.08), in: Capsule())
                }
                .buttonStyle(.plain)
            }

            if recentLogLines.isEmpty {
                Text("还没有记录。点上面的按钮，这里会一行一行写下来。")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.42))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                VStack(alignment: .leading, spacing: 5) {
                    ForEach(Array(recentLogLines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 10, weight: .medium, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.70))
                            .lineLimit(2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
        )
    }

    private var recentLogLines: [String] {
        let tail = appLog.entries.suffix(8)
        return tail.map { line in
            if line.hasPrefix("[OGIOS] ") {
                return String(line.dropFirst(8))
            }
            return line
        }
    }

    // MARK: - 补丁（进阶区保留原功能）

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("PATCH OPTIONS", icon: "bolt.fill")
                Spacer()
                Text("SELECT TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCard(name: "Aim Drag", target: "FREE FIRE • NORMAL", package: "OGIOS File (6).3105", color: HomeTheme.accent, state: $aimDragEnabled)
                patchCard(name: "Aim Neck", target: "FREE FIRE • NORMAL", package: "OGIOS File (7).3105", color: HomeTheme.blue, state: $aimNeckEnabled)
                patchCard(name: "Antenna", target: "FREE FIRE • NORMAL", package: "OGIOS File (8).3105", color: HomeTheme.blue, state: $hspeitoffEnabled)
                patchCard(name: "144 FPS", target: "FREE FIRE • NORMAL", package: "OGIOS File (10).3105", color: HomeTheme.blue, state: $hyperBalamagicaEnabled)
                patchCard(name: "Aim Body", target: "FREE FIRE • NORMAL", package: "OGIOS File (12).3105", color: HomeTheme.accent, state: $aimBodyPackageEnabled)
                patchCard(name: "Aim Chest", target: "FREE FIRE • NORMAL", package: "OGIOS File (2).3105", color: HomeTheme.blue, state: $aimChestPackageEnabled)
                patchCard(name: "Magic", target: "FREE FIRE • NORMAL", package: "OGIOS File (14).3105", color: HomeTheme.accent, state: $magicEnabled)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("successful") ? HomeTheme.accent : HomeTheme.yellow).frame(width: 7, height: 7)
                Text(patchOperationBusy ? "PROCESSING PATCH…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCard(name: String, target: String, package: String, color: Color, state: Binding<Bool>) -> some View {
        PatchOptionCard(name: name, target: target, color: color, isEnabled: state, isBusy: patchOperationBusy) {
            togglePatch(packageFilename: package, state: state)
        }
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("LAUNCH GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF NORMAL", subtitle: "Free Fire Normal", color: HomeTheme.accent, scheme: "freefireth")
                lockedLaunchButton(title: "FF MAX", subtitle: "Locked • Coming Soon", color: HomeTheme.blue)
            }
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func lockedLaunchButton(title: String, subtitle: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: "lock.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(color.opacity(0.72))
            Text(title)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
            Text(subtitle)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(color.opacity(0.72))
        }
        .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
        .padding(.horizontal, 14)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.24), lineWidth: 1))
        .opacity(0.72)
        .accessibilityLabel("FF MAX locked, coming soon")
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(HomeTheme.accent)
    }

    private func syncPatchStates() {
        aimDragEnabled = isPatchActive("OGIOS File (6).3105")
        aimNeckEnabled = isPatchActive("OGIOS File (7).3105")
        hspeitoffEnabled = isPatchActive("OGIOS File (8).3105")
        hyperBalamagicaEnabled = isPatchActive("OGIOS File (10).3105")
        aimBodyPackageEnabled = isPatchActive("OGIOS File (12).3105")
        aimChestPackageEnabled = isPatchActive("OGIOS File (2).3105")
        magicEnabled = isPatchActive("OGIOS File (14).3105")
    }

    private func isPatchActive(_ packageFilename: String) -> Bool {
        patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame })
            .flatMap { DevicePatchService.latestReceipt(projectID: $0.id) } != nil
    }

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        switch packageFilename {
        case "OGIOS File (6).3105": aimDragEnabled = enabled
        case "OGIOS File (7).3105": aimNeckEnabled = enabled
        case "OGIOS File (8).3105": hspeitoffEnabled = enabled
        case "OGIOS File (10).3105": hyperBalamagicaEnabled = enabled
        case "OGIOS File (12).3105": aimBodyPackageEnabled = enabled
        case "OGIOS File (2).3105": aimChestPackageEnabled = enabled
        case "OGIOS File (14).3105": magicEnabled = enabled
        default: break
        }
    }

    private func togglePatch(packageFilename: String, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        guard let item = patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame }) else {
            patchMessage = "ERROR — PACKAGE NOT FOUND"
            log("patch: package not found: \(packageFilename)")
            return
        }

        let wasEnabled = state.wrappedValue
        patchOperationBusy = true
        patchMessage = "PROCESSING — \(packageFilename)"
        let project = item.project
        let projectID = item.id

        DispatchQueue.global(qos: .userInitiated).async {
            let result: PatchActionResult
            do {
                if wasEnabled {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        result = .unavailable("NO ACTIVE RECEIPT — NOTHING TO RESTORE")
                        DispatchQueue.main.async {
                            self.setPatchState(for: packageFilename, enabled: false)
                            self.patchMessage = "OFF — NO ACTIVE PATCH FOUND"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                    result = .restored
                } else {
                    guard let project else {
                        result = .unavailable("PASSWORD REQUIRED — UNLOCK PACKAGE")
                        DispatchQueue.main.async {
                            self.patchStore.requestUnlock(for: item)
                            self.patchMessage = "PASSWORD REQUIRED — ENTER PACKAGE PASSWORD"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    _ = try DevicePatchService.apply(project: project)
                    result = .applied
                }
            } catch {
                result = .unavailable("FAILED — \(String(describing: error))")
            }

            DispatchQueue.main.async {
                switch result {
                case .applied:
                    self.setPatchState(for: packageFilename, enabled: true)
                    self.patchMessage = "Inject Successful — \(packageFilename)"
                    PatchAudioFeedback.bypassActivated()
                case .restored:
                    self.setPatchState(for: packageFilename, enabled: false)
                    self.patchMessage = "Restore Successful — \(packageFilename)"
                    PatchAudioFeedback.originalRestored()
                case .unavailable(let message):
                    self.patchMessage = message
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { success in
            log("launch: \(scheme) success=\(success)")
        }
    }

    private var developerCredits: some View {
        Text("浪神文件管理器 · 内核引擎来自 OGIOS")
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.55))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
    }
}

// MARK: - 首页配色

enum HomeTheme {
    static let accent = Color(red: 0.24, green: 0.90, blue: 0.58)
    static let green = Color(red: 0.13, green: 0.60, blue: 0.36)
    static let red = Color(red: 0.62, green: 0.16, blue: 0.18)
    static let blue = Color(red: 0.14, green: 0.40, blue: 0.68)
    static let purple = Color(red: 0.42, green: 0.24, blue: 0.72)
    static let yellow = Color(red: 0.96, green: 0.78, blue: 0.29)
    static let card = Color.black.opacity(0.40)
    static let warnBackground = Color(red: 0.85, green: 0.66, blue: 0.16).opacity(0.22)
    static let warnBorder = Color(red: 0.96, green: 0.78, blue: 0.29).opacity(0.55)
    static let warnText = Color(red: 0.99, green: 0.90, blue: 0.62)
}

// MARK: - 游戏内 pak 列表

struct GamePakListSheet: View {
    @ObservedObject var importer: PaksImporter
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if importer.gamePaks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "shippingbox")
                            .font(.system(size: 30, weight: .medium))
                            .foregroundStyle(.secondary)
                        Text(importer.containerFound ? "游戏 Paks 里还没有 pak" : "还没定位到游戏目录")
                            .font(.headline)
                        Text(importer.containerFound
                             ? "先启动一次游戏，让它生成 Paks 目录，再回来点刷新。"
                             : "先回首页点「⚡ 一键激活内核」，状态变绿之后再点④。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(28)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        Section {
                            ForEach(importer.gamePaks) { pak in
                                HStack(spacing: 10) {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(HomeTheme.accent)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(pak.name)
                                            .font(.system(size: 13, weight: .semibold))
                                            .lineLimit(1)
                                        Text(pak.sizeText)
                                            .font(.system(size: 10, weight: .medium))
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if importer.importedFiles.contains(pak.name) {
                                        Text("我导入的")
                                            .font(.system(size: 9, weight: .bold))
                                            .foregroundStyle(HomeTheme.accent)
                                            .padding(.horizontal, 7)
                                            .padding(.vertical, 3)
                                            .background(HomeTheme.accent.opacity(0.14), in: Capsule())
                                    }
                                }
                            }
                        } footer: {
                            Text("共 \(importer.gamePaks.count) 个文件 · \(importer.matchedBundleID)")
                        }
                    }
                }
            }
            .navigationTitle("游戏里的包")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("刷新") { importer.refreshGamePaks() }
                }
            }
        }
    }
}

// MARK: - 补丁卡片

private struct PatchOptionCard: View {
    let name: String
    let target: String
    let color: Color
    @Binding var isEnabled: Bool
    let isBusy: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 11) {
                HStack {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(color)
                    Spacer()
                    Circle()
                        .fill(isEnabled ? color : Color.white.opacity(0.20))
                        .frame(width: 9, height: 9)
                }
                Text(name)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(target)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
                Text(isEnabled ? "ON" : "OFF")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(isEnabled ? color : Color.white.opacity(0.35))
            }
            .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
            .padding(14)
            .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(isEnabled ? color.opacity(0.85) : color.opacity(0.28), lineWidth: isEnabled ? 1.5 : 1))
            .shadow(color: isEnabled ? color.opacity(0.20) : .clear, radius: 12)
        }
        .buttonStyle(.plain)
        .disabled(isBusy)
        .opacity(isBusy ? 0.55 : 1)
        .accessibilityLabel("\(name), \(target), \(isEnabled ? "On" : "Off")")
    }
}

private struct PatchUnlockPrompt: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Package password", text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(AppLanguage.english.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text("Enter the password once to unlock this OGIOS package on this device.")
                }
            }
            .navigationTitle("Unlock package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Unlock", action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle()
                    .fill(HomeTheme.accent.opacity(0.10))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle()
                    .fill(HomeTheme.blue.opacity(0.10))
                    .frame(width: 260, height: 260)
                    .blur(radius: 80)
                    .offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(HomeTheme.accent.opacity(0.05)), lineWidth: 1)
        }
    }
}

// MARK: - 文件选择器

struct PakDocumentPicker: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let pakType = UTType(filenameExtension: "pak") ?? UTType.data
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [pakType, .data], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {}
    }
}

// MARK: - 和平精英 Paks 一键导入 / 删除

struct GamePak: Identifiable, Equatable {
    let id: String
    let name: String
    let size: Int64

    var sizeText: String {
        if size >= 1_048_576 {
            return String(format: "%.1f MB", Double(size) / 1_048_576.0)
        }
        if size >= 1024 {
            return String(format: "%.0f KB", Double(size) / 1024.0)
        }
        return "\(size) B"
    }
}

// MARK: - 导入 / 修复 结果弹窗

struct PaksAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    var success: Bool = true
}

final class PaksImporter: ObservableObject {
    static let shared = PaksImporter()

    @Published var inboxFiles: [String] = []
    @Published var importedFiles: [String] = []
    @Published var gamePaks: [GamePak] = []
    @Published var busy = false
    @Published var statusText = "待机"
    @Published var containerFound = false
    @Published var matchedBundleID = ""
    @Published var paksCount = 0
    @Published var lastResult = ""
    @Published var pendingAlert: PaksAlert?
    @Published var backupEnabled = true
    @Published var wipeBackupEnabled = true

    private let fm = FileManager.default
    private static let recordFileName = "imported-paks.json"
    private static let inboxFolderName = "PakInbox"
    private static let backupFolderName = "PakBackup"
    private static let backupKey = "ls.paks.backup"
    private static let wipeBackupKey = "ls.paks.wipebackup"

    private init() {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: Self.backupKey) != nil {
            backupEnabled = defaults.bool(forKey: Self.backupKey)
        }
        if defaults.object(forKey: Self.wipeBackupKey) != nil {
            wipeBackupEnabled = defaults.bool(forKey: Self.wipeBackupKey)
        }
    }

    // MARK: - 弹窗控制（自绘浮层）

    func dismissAlert() {
        pendingAlert = nil
    }

    func showAlert(_ title: String, _ message: String, success: Bool = true) {
        DispatchQueue.main.async {
            self.pendingAlert = PaksAlert(title: title, message: message, success: success)
            UINotificationFeedbackGenerator().notificationOccurred(success ? .success : .warning)
        }
    }

    private static var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    private static var recordsURL: URL {
        documentsURL.appendingPathComponent(recordFileName)
    }

    private static var inboxURL: URL {
        documentsURL.appendingPathComponent(inboxFolderName, isDirectory: true)
    }

    private static var backupURL: URL {
        documentsURL.appendingPathComponent(backupFolderName, isDirectory: true)
    }

    // 和平精英各服包名，按顺序试
    private static let candidateBundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.tencent.tmgp.pubgmhd.dev"
    ]

    // MARK: - 开关

    func setBackup(_ on: Bool) {
        backupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.backupKey)
    }

    func setWipeBackup(_ on: Bool) {
        wipeBackupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.wipeBackupKey)
    }

    // MARK: - 外部递进来的文件（文件 App → 打开方式 / 共享）

    static func handles(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return ext == "pak" || ext == "sig"
    }

    func ingestExternal(url: URL) {
        log("external: 收到文件 App 递进来的 \(url.lastPathComponent)")
        add(urls: [url])
        lastResult = "文件 App 递进来 \(url.lastPathComponent)，已放进「待导入」"
        statusText = lastResult
    }

    // MARK: - 状态刷新

    func refresh() {
        DispatchQueue.global(qos: .userInitiated).async {
            let names = self.scanPakFiles()
            let records = self.loadRecords()
            let container = self.resolveContainer()
            var count = 0
            var paks: [GamePak] = []
            if let container = container {
                let paksPath = self.paksPath(for: container.path)
                let handle = ContainerStore.grantContainerAccess(container.path)
                paks = self.listGamePaks(at: paksPath)
                count = paks.count
                if handle >= 0 { bad_query_release(handle) }
            }
            DispatchQueue.main.async {
                self.inboxFiles = names
                self.importedFiles = records
                self.containerFound = container != nil
                self.matchedBundleID = container?.id ?? ""
                self.paksCount = count
                self.gamePaks = paks
            }
        }
    }

    func refreshGamePaks() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.containerFound = false
                    self.gamePaks = []
                    self.paksCount = 0
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或者先启动一次游戏。"
                }
                return
            }
            let path = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let paks = self.listGamePaks(at: path)
            if handle >= 0 { bad_query_release(handle) }
            log("paks: 扫描游戏 Paks，找到 \(paks.count) 个文件")
            DispatchQueue.main.async {
                self.containerFound = true
                self.matchedBundleID = container.id
                self.gamePaks = paks
                self.paksCount = paks.count
                self.lastResult = "游戏 Paks 里现在有 \(paks.count) 个文件"
            }
        }
    }

    // MARK: - 添加文件

    func add(urls: [URL]) {
        guard !urls.isEmpty else { return }
        try? fm.createDirectory(at: Self.inboxURL, withIntermediateDirectories: true)
        for url in urls {
            let destination = Self.inboxURL.appendingPathComponent(url.lastPathComponent)
            let scoped = url.startAccessingSecurityScopedResource()
            if fm.fileExists(atPath: destination.path) {
                try? fm.removeItem(at: destination)
            }
            do {
                try fm.copyItem(at: url, to: destination)
                log("paks: 已添加到待导入 \(url.lastPathComponent)")
            } catch {
                log("paks: 添加失败 \(url.lastPathComponent) — \(error.localizedDescription)")
            }
            if scoped { url.stopAccessingSecurityScopedResource() }
        }
        refresh()
        statusText = "已添加到 App"
    }

    // MARK: - 一键导入（覆盖原件）

    func importAll() {
        guard !busy else { return }
        let files = inboxFiles
        guard !files.isEmpty else {
            statusText = "先添加 pak 文件"
            lastResult = "待导入是空的：点「③ 从手机里选文件」，或在文件 App 里长按 pak → 共享 → 浪神文件管理器。"
            showAlert(
                "没有待导入的文件",
                "待导入列表现在是空的。先点「③ 从手机里选文件」，或者在「文件」App 里长按 pak → 共享 → 浪神文件管理器，选进来再点「① 导入文件」。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在导入…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "导入失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「① 导入文件」。",
                        success: false
                    )
                }
                log("paks: 容器解析失败")
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            if !self.fm.fileExists(atPath: paks) {
                do {
                    try self.fm.createDirectory(atPath: paks, withIntermediateDirectories: true)
                } catch {
                    log("paks: 创建 Paks 目录失败 \(error.localizedDescription)")
                }
            }

            var done: [String] = []
            var failed: [String] = []
            for name in files {
                guard let source = self.findFile(named: name) else {
                    failed.append(name)
                    continue
                }
                let destination = paks + "/" + name
                if self.backupEnabled {
                    self.backupOriginal(at: destination, name: name)
                }
                do {
                    try self.installCopy(from: source, to: destination)
                    done.append(name)
                    log("paks: 已覆盖 \(name)")
                } catch {
                    failed.append(name)
                    log("paks: 导入失败 \(name) — \(error.localizedDescription)")
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            var records = self.loadRecords()
            for name in done where !records.contains(name) {
                records.append(name)
            }
            self.saveRecords(records)

            let summary: String
            if done.isEmpty {
                summary = "一个都没导进去（失败 \(failed.count) 个）"
            } else if failed.isEmpty {
                summary = "已导入 \(done.count) 个，游戏里的原件已覆盖"
            } else {
                summary = "导入 \(done.count) 个，失败 \(failed.count) 个"
            }

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = records
                if !done.isEmpty {
                    if failed.isEmpty {
                        self.showAlert(
                            "导入成功",
                            "已导入 \(done.count) 个文件，游戏里的原件已经覆盖，进游戏就是新内容。"
                        )
                    } else {
                        self.showAlert(
                            "导入完成，有失败",
                            "已导入 \(done.count) 个，\(failed.count) 个没成功：\n" + failed.joined(separator: "、") + "\n\n没成功的可以再点一次「① 导入文件」重试。",
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "导入失败",
                        "一个都没导进去（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「① 导入文件」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - 一键修复（直接删掉导入的文件，不还原原件）

    func deleteImported() {
        guard !busy else { return }
        let names = importedFiles
        guard !names.isEmpty else {
            statusText = "还没有导入记录"
            lastResult = "还没导入过东西：先点「① 导入文件」。"
            showAlert(
                "没有可修复的文件",
                "现在还没有导入记录，没有东西可以删。先点「① 导入文件」，导进去之后再点「② 修复」，就会把导进去的文件从游戏里直接删掉。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在修复…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "修复失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「② 修复」。",
                        success: false
                    )
                }
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            var removed: [String] = []
            var failed: [String] = []

            for name in names {
                let path = paks + "/" + name
                var succeeded = false
                if self.fm.fileExists(atPath: path) {
                    do {
                        try self.fm.removeItem(atPath: path)
                        removed.append(name)
                        succeeded = true
                        log("paks: 已从游戏里删除 \(name)")
                    } catch {
                        failed.append(name)
                        log("paks: 删除失败 \(name) — \(error.localizedDescription)")
                    }
                } else {
                    removed.append(name)
                    succeeded = true
                }

                if succeeded && self.wipeBackupEnabled {
                    self.deleteBackup(name: name)
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            let keep = names.filter { !removed.contains($0) }
            self.saveRecords(keep)

            let summary = failed.isEmpty
                ? "已把 \(removed.count) 个文件从游戏里删掉"
                : "删掉 \(removed.count) 个，失败 \(failed.count) 个"

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = keep
                if !removed.isEmpty {
                    if failed.isEmpty {
                        self.showAlert(
                            "修复成功",
                            "已把 \(removed.count) 个文件从游戏里直接删掉，没有还原原件，游戏里现在没有这些文件了。"
                        )
                    } else {
                        self.showAlert(
                            "修复完成，有失败",
                            "已删掉 \(removed.count) 个，\(failed.count) 个没删成功：\n" + failed.joined(separator: "、"),
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "修复失败",
                        "一个都没删掉（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「② 修复」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - 认领 / 清记录

    func claimImported() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let inbox = Set(self.scanPakFiles())
            var records = self.loadRecords()
            var added: [String] = []
            for name in inside where inbox.contains(name) && !records.contains(name) {
                records.append(name)
                added.append(name)
            }
            self.saveRecords(records)
            log("paks: 认领 \(added.count) 个已导入文件")

            DispatchQueue.main.async {
                self.importedFiles = records
                self.lastResult = added.isEmpty
                    ? "没有可认领的（游戏里没有和待导入同名的包）"
                    : "认领了 \(added.count) 个：" + added.joined(separator: "、")
                self.refresh()
            }
        }
    }

    func clearStaleRecords() {
        DispatchQueue.global(qos: .userInitiated).async {
            let records = self.loadRecords()
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let keep = records.filter { inside.contains($0) }
            let dropped = records.count - keep.count
            self.saveRecords(keep)
            log("paks: 清掉 \(dropped) 条失效记录")

            DispatchQueue.main.async {
                self.importedFiles = keep
                self.lastResult = dropped == 0 ? "没有失效记录" : "清掉了 \(dropped) 条失效记录"
                self.refresh()
            }
        }
    }

    // MARK: - 内部

    private func paksPath(for container: String) -> String {
        container + "/Documents/ShadowTrackerExtra/Saved/Paks"
    }

    private func listGamePaks(at path: String) -> [GamePak] {
        guard let names = try? fm.contentsOfDirectory(atPath: path) else { return [] }
        var list: [GamePak] = []
        for name in names {
            let lowered = name.lowercased()
            guard lowered.hasSuffix(".pak") || lowered.hasSuffix(".sig") else { continue }
            let full = path + "/" + name
            let attrs = try? fm.attributesOfItem(atPath: full)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            list.append(GamePak(id: name, name: name, size: size))
        }
        return list.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private func backupOriginal(at destination: String, name: String) {
        guard fm.fileExists(atPath: destination) else { return }
        try? fm.createDirectory(at: Self.backupURL, withIntermediateDirectories: true)
        let target = Self.backupURL.appendingPathComponent(name)
        guard !fm.fileExists(atPath: target.path) else { return }
        do {
            try fm.copyItem(atPath: destination, toPath: target.path)
            log("paks: 已备份原件 \(name)")
        } catch {
            log("paks: 备份原件失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func deleteBackup(name: String) {
        let backup = Self.backupURL.appendingPathComponent(name)
        guard fm.fileExists(atPath: backup.path) else { return }
        do {
            try fm.removeItem(at: backup)
            log("paks: 已删掉备份 \(name)")
        } catch {
            log("paks: 删备份失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func resolveContainer() -> (id: String, path: String)? {
        for bundleID in Self.candidateBundleIDs {
            if let path = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
                return (bundleID, path)
            }
        }

        var enumerationError: NSString?
        let identifiers = MCMEnumerateIdentifiersForClass(2, 4_096, &enumerationError)
        for identifier in identifiers {
            let lowered = identifier.lowercased()
            guard lowered.contains("pubg") || lowered.contains("tmgp") || lowered.contains("rekoo") else { continue }
            if let path = ContainerStore.resolveAppContainerPath(bundleID: identifier) {
                return (identifier, path)
            }
        }

        // 兜底：直接扫容器元数据（MCM 拒绝时走这条）
        let apps = ContainerStore.containersFromFilesystem()
        for app in apps {
            let lowered = app.bundleID.lowercased()
            let isGame = Self.candidateBundleIDs.contains(app.bundleID)
                || lowered.contains("pubg")
                || lowered.contains("tmgp")
                || lowered.contains("rekoo")
            if isGame {
                return (app.bundleID, app.containerPath)
            }
        }
        return nil
    }

    private func scanPakFiles() -> [String] {
        var names: [String] = []
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return names
        }
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            guard ext == "pak" || ext == "sig" else { continue }
            guard !url.path.contains(Self.backupFolderName) else { continue }
            names.append(url.lastPathComponent)
        }
        return Array(Set(names)).sorted()
    }

    private func findFile(named name: String) -> URL? {
        let inbox = Self.inboxURL.appendingPathComponent(name)
        if fm.fileExists(atPath: inbox.path) { return inbox }
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }
        for case let url as URL in enumerator where url.lastPathComponent == name {
            guard !url.path.contains(Self.backupFolderName) else { continue }
            return url
        }
        return nil
    }

    private func installCopy(from source: URL, to destination: String) throws {
        let temporary = destination + ".tmp-" + String(UUID().uuidString.prefix(8))
        if fm.fileExists(atPath: temporary) {
            try? fm.removeItem(atPath: temporary)
        }
        do {
            try fm.copyItem(at: source, to: URL(fileURLWithPath: temporary))
        } catch {
            // 临时文件占双倍空间，空间紧时退回「先腾位再直写」
            if fm.fileExists(atPath: destination) {
                try? fm.removeItem(atPath: destination)
            }
            try fm.copyItem(at: source, to: URL(fileURLWithPath: destination))
            return
        }

        if fm.fileExists(atPath: destination) {
            do {
                _ = try fm.replaceItemAt(
                    URL(fileURLWithPath: destination),
                    withItemAt: URL(fileURLWithPath: temporary),
                    backupItemName: nil,
                    options: []
                )
                return
            } catch {
                try? fm.removeItem(atPath: destination)
            }
        }
        try fm.moveItem(atPath: temporary, toPath: destination)
    }

    private func loadRecords() -> [String] {
        guard let data = try? Data(contentsOf: Self.recordsURL),
              let list = try? JSONDecoder().decode([String].self, from: data) else {
            return []
        }
        return list
    }

    private func saveRecords(_ names: [String]) {
        guard let data = try? JSONEncoder().encode(names) else { return }
        try? data.write(to: Self.recordsURL)
    }
}
